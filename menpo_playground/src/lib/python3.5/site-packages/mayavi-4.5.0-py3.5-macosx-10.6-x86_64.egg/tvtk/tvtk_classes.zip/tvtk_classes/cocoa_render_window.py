# Automatically generated code: EDIT AT YOUR OWN RISK
from traits import api as traits
from traitsui.item import Item, spring
from traitsui.group import HGroup
from traitsui.view import View

from tvtk import vtk_module as vtk
from tvtk import tvtk_base
from tvtk.tvtk_base_handler import TVTKBaseHandler
from tvtk import messenger
from tvtk.tvtk_base import deref_vtk
from tvtk import array_handler
from tvtk.array_handler import deref_array
from tvtk.tvtk_classes.tvtk_helper import wrap_vtk


def InstanceEditor(*args, **kw):
    from traitsui.editors.api import InstanceEditor as Editor
    return Editor(view_name="handler.view")

try:
    long
except NameError:
    # Silly workaround for Python3.
    long = int

from tvtk.tvtk_classes.open_gl_render_window import OpenGLRenderWindow


class CocoaRenderWindow(OpenGLRenderWindow):
    """
    CocoaRenderWindow - Cocoa open_gl rendering window
    
    Superclass: OpenGLRenderWindow
    
    CocoaRenderWindow is a concrete implementation of the abstract
    class OpenGLRenderWindow. It is only available on Mac OS X 10.6
    and later. To use this class, build VTK with VTK_USE_COCOA turned ON
    (this is the default). This class can be used by 32 and 64 bit
    processes, and either in garbage collected or reference counted
    modes. ARC is not yet supported. CocoaRenderWindow uses
    Objective-C++, and the open_gl and Cocoa APIs. This class's default
    behaviour is to create an NSWindow and a CocoaGLView which are
    used together to draw all VTK content. If you already have an
    NSWindow and CocoaGLView and you want this class to use them you
    must call both set_root_window() and set_window_id(), respectively, early
    on (before window_initialize() is executed).
    
    See Also:
    
    OpenGLRenderWindow CocoaGLView
    
    """
    def __init__(self, obj=None, update=True, **traits):
        tvtk_base.TVTKBase.__init__(self, vtk.vtkCocoaRenderWindow, obj, update, **traits)
    
    current_cursor = traits.Int(0, enter_set=True, auto_set=False, help=\
        """
        Change the shape of the cursor.
        """
    )

    def _current_cursor_changed(self, old_val, new_val):
        self._do_change(self._vtk_obj.SetCurrentCursor,
                        self.current_cursor)

    def _get_pixel_format(self):
        return self._vtk_obj.GetPixelFormat()
    def _set_pixel_format(self, arg):
        old_val = self._get_pixel_format()
        self._wrap_call(self._vtk_obj.SetPixelFormat,
                        arg)
        self.trait_property_changed('pixel_format', old_val, arg)
    pixel_format = traits.Property(_get_pixel_format, _set_pixel_format, help=\
        """
        Accessors for the pixel format object (Really an
        ns_open_gl_pixel_format*).
        """
    )

    size = traits.Array(enter_set=True, auto_set=False, shape=(2,), dtype=int, value=(0, 0), cols=2, help=\
        """
        Set the size of the window in pixels.
        """
    )

    def _size_changed(self, old_val, new_val):
        self._do_change(self._vtk_obj.SetSize,
                        self.size)

    def _get_window_id(self):
        return self._vtk_obj.GetWindowId()
    def _set_window_id(self, arg):
        old_val = self._get_window_id()
        self._wrap_call(self._vtk_obj.SetWindowId,
                        arg)
        self.trait_property_changed('window_id', old_val, arg)
    window_id = traits.Property(_get_window_id, _set_window_id, help=\
        """
        Returns the NSView* associated with this RenderWindow.
        """
    )

    def _get_parent_id(self):
        return self._vtk_obj.GetParentId()
    def _set_parent_id(self, arg):
        old_val = self._get_parent_id()
        self._wrap_call(self._vtk_obj.SetParentId,
                        arg)
        self.trait_property_changed('parent_id', old_val, arg)
    parent_id = traits.Property(_get_parent_id, _set_parent_id, help=\
        """
        Get the parent NSView* for this RenderWindow.  This method
        will return "NULL" if the parent was not set with set_parent_id()
        or set_parent_info().
        """
    )

    def _get_root_window(self):
        return self._vtk_obj.GetRootWindow()
    def _set_root_window(self, arg):
        old_val = self._get_root_window()
        self._wrap_call(self._vtk_obj.SetRootWindow,
                        arg)
        self.trait_property_changed('root_window', old_val, arg)
    root_window = traits.Property(_get_root_window, _set_root_window, help=\
        """
        Returns the NSWindow* associated with this RenderWindow.
        """
    )

    position = traits.Array(enter_set=True, auto_set=False, shape=(2,), dtype=int, value=(0, 0), cols=2, help=\
        """
        Set the position of the window.
        """
    )

    def _position_changed(self, old_val, new_val):
        self._do_change(self._vtk_obj.SetPosition,
                        self.position)

    window_name = traits.String('Visualization Toolkit - Cocoa', enter_set=True, auto_set=False, help=\
        """
        Set the name of the window. This appears at the top of the window
        normally.
        """
    )

    def _window_name_changed(self, old_val, new_val):
        self._do_change(self._vtk_obj.SetWindowName,
                        self.window_name)

    def _get_context_id(self):
        return self._vtk_obj.GetContextId()
    def _set_context_id(self, arg):
        old_val = self._get_context_id()
        self._wrap_call(self._vtk_obj.SetContextId,
                        arg)
        self.trait_property_changed('context_id', old_val, arg)
    context_id = traits.Property(_get_context_id, _set_context_id, help=\
        """
        Accessors for the open_gl context (Really an ns_open_gl_context*).
        """
    )

    def _get_view_created(self):
        return self._vtk_obj.GetViewCreated()
    view_created = traits.Property(_get_view_created, help=\
        """
        Get the view_created flag. It is 1 if this object created an
        instance of NSView, 0 otherwise.
        """
    )

    def _get_window_created(self):
        return self._vtk_obj.GetWindowCreated()
    window_created = traits.Property(_get_window_created, help=\
        """
        Get the window_created flag. It is 1 if this object created an
        instance of NSWindow, 0 otherwise.
        """
    )

    def initialize(self):
        """
        V.initialize()
        C++: virtual void Initialize()
        Initialize the rendering window.
        """
        ret = self._vtk_obj.Initialize()
        return ret
        

    def pref_full_screen(self):
        """
        V.pref_full_screen()
        C++: virtual void PrefFullScreen()
        Set the preferred window size to full screen.  This is not
        implemented for the CocoaRenderWindow.
        """
        ret = self._vtk_obj.PrefFullScreen()
        return ret
        

    def setup_palette(self, *args):
        """
        V.setup_palette(void)
        C++: virtual void SetupPalette(void *hDC)
        Initialize open_gl for this window.
        """
        ret = self._wrap_call(self._vtk_obj.SetupPalette, *args)
        return ret

    def setup_pixel_format(self, *args):
        """
        V.setup_pixel_format(void, void, int, int, int)
        C++: virtual void SetupPixelFormat(void *hDC, void *dwFlags,
            int debug, int bpp=16, int zbpp=16)
        Initialize open_gl for this window.
        """
        ret = self._wrap_call(self._vtk_obj.SetupPixelFormat, *args)
        return ret

    def update_context(self):
        """
        V.update_context()
        C++: void UpdateContext()
        Update this window's open_gl context, e.g. when the window is
        resized.
        """
        ret = self._vtk_obj.UpdateContext()
        return ret
        

    def window_configure(self):
        """
        V.window_configure()
        C++: virtual void WindowConfigure()
        Specify various window parameters.
        """
        ret = self._vtk_obj.WindowConfigure()
        return ret
        

    _updateable_traits_ = \
    (('point_smoothing', 'GetPointSmoothing'),
    ('context_supports_open_gl32', 'GetContextSupportsOpenGL32'),
    ('line_smoothing', 'GetLineSmoothing'), ('swap_buffers',
    'GetSwapBuffers'), ('reference_count', 'GetReferenceCount'),
    ('fd_frames', 'GetFDFrames'), ('position', 'GetPosition'),
    ('window_name', 'GetWindowName'), ('polygon_smoothing',
    'GetPolygonSmoothing'), ('size', 'GetSize'), ('stereo_capable_window',
    'GetStereoCapableWindow'), ('global_warning_display',
    'GetGlobalWarningDisplay'), ('anaglyph_color_saturation',
    'GetAnaglyphColorSaturation'), ('mapped', 'GetMapped'), ('tile_scale',
    'GetTileScale'), ('double_buffer', 'GetDoubleBuffer'),
    ('off_screen_rendering', 'GetOffScreenRendering'),
    ('anaglyph_color_mask', 'GetAnaglyphColorMask'),
    ('use_constant_fd_offsets', 'GetUseConstantFDOffsets'), ('is_picking',
    'GetIsPicking'), ('debug', 'GetDebug'), ('full_screen',
    'GetFullScreen'), ('desired_update_rate', 'GetDesiredUpdateRate'),
    ('dpi', 'GetDPI'), ('stencil_capable', 'GetStencilCapable'),
    ('stereo_render', 'GetStereoRender'), ('erase', 'GetErase'),
    ('alpha_bit_planes', 'GetAlphaBitPlanes'), ('borders', 'GetBorders'),
    ('current_cursor', 'GetCurrentCursor'), ('aa_frames', 'GetAAFrames'),
    ('number_of_layers', 'GetNumberOfLayers'), ('sub_frames',
    'GetSubFrames'), ('device_index', 'GetDeviceIndex'),
    ('in_abort_check', 'GetInAbortCheck'), ('multi_samples',
    'GetMultiSamples'), ('tile_viewport', 'GetTileViewport'),
    ('stereo_type', 'GetStereoType'), ('abort_render', 'GetAbortRender'),
    ('global_maximum_number_of_multi_samples',
    'GetGlobalMaximumNumberOfMultiSamples'))
    
    _allow_update_failure_ = \
    ()
    
    _full_traitnames_list_ = \
    (['borders', 'debug', 'double_buffer', 'erase', 'full_screen',
    'global_warning_display', 'is_picking', 'line_smoothing', 'mapped',
    'off_screen_rendering', 'point_smoothing', 'polygon_smoothing',
    'stencil_capable', 'stereo_capable_window', 'stereo_render',
    'swap_buffers', 'stereo_type', 'aa_frames', 'abort_render',
    'alpha_bit_planes', 'anaglyph_color_mask',
    'anaglyph_color_saturation', 'context_supports_open_gl32',
    'current_cursor', 'desired_update_rate', 'device_index', 'dpi',
    'fd_frames', 'global_maximum_number_of_multi_samples',
    'in_abort_check', 'multi_samples', 'number_of_layers', 'position',
    'size', 'sub_frames', 'tile_scale', 'tile_viewport',
    'use_constant_fd_offsets', 'window_name'])
    
    def trait_view(self, name=None, view_element=None):
        if view_element is not None or name not in (None, '', 'traits_view', 'full_traits_view', 'view'):
            return super(CocoaRenderWindow, self).trait_view(name, view_element)
        if name == 'full_traits_view':
            full_traits_view = \
            View((Item("handler._full_traits_list",show_label=False)),
            title='Edit CocoaRenderWindow properties', scrollable=True, resizable=True,
            handler=TVTKBaseHandler,
            buttons=['OK', 'Cancel'])
            return full_traits_view
        elif name == 'view':
            view = \
            View((['borders', 'double_buffer', 'erase', 'full_screen',
            'is_picking', 'line_smoothing', 'mapped', 'off_screen_rendering',
            'point_smoothing', 'polygon_smoothing', 'stencil_capable',
            'stereo_capable_window', 'stereo_render', 'swap_buffers'],
            ['stereo_type'], ['aa_frames', 'abort_render', 'alpha_bit_planes',
            'anaglyph_color_mask', 'anaglyph_color_saturation',
            'context_supports_open_gl32', 'current_cursor', 'desired_update_rate',
            'device_index', 'dpi', 'fd_frames',
            'global_maximum_number_of_multi_samples', 'in_abort_check',
            'multi_samples', 'number_of_layers', 'position', 'size', 'sub_frames',
            'tile_scale', 'tile_viewport', 'use_constant_fd_offsets',
            'window_name']),
            title='Edit CocoaRenderWindow properties', scrollable=True, resizable=True,
            handler=TVTKBaseHandler,
            buttons=['OK', 'Cancel'])
            return view
        elif name in (None, 'traits_view'):
            traits_view = \
            View((HGroup(spring, "handler.view_type", show_border=True), 
            Item("handler.info.object", editor = InstanceEditor(view_name="handler.view"), style = "custom", show_label=False)),
            title='Edit CocoaRenderWindow properties', scrollable=True, resizable=True,
            handler=TVTKBaseHandler,
            buttons=['OK', 'Cancel'])
            return traits_view
            

