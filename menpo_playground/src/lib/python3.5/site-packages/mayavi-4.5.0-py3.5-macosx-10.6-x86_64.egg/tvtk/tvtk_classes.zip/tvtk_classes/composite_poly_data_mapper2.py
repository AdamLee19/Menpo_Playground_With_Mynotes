# Automatically generated code: EDIT AT YOUR OWN RISK
from traits import api as traits
from traitsui.item import Item, spring
from traitsui.group import HGroup
from traitsui.view import View

from tvtk import vtk_module as vtk
from tvtk import tvtk_base
from tvtk.tvtk_base_handler import TVTKBaseHandler
from tvtk import messenger
from tvtk.tvtk_base import deref_vtk
from tvtk import array_handler
from tvtk.array_handler import deref_array
from tvtk.tvtk_classes.tvtk_helper import wrap_vtk


def InstanceEditor(*args, **kw):
    from traitsui.editors.api import InstanceEditor as Editor
    return Editor(view_name="handler.view")

try:
    long
except NameError:
    # Silly workaround for Python3.
    long = int

from tvtk.tvtk_classes.generic_composite_poly_data_mapper2 import GenericCompositePolyDataMapper2


class CompositePolyDataMapper2(GenericCompositePolyDataMapper2):
    """
    CompositePolyDataMapper2 - mapper for composite dataset
    
    Superclass: GenericCompositePolyDataMapper2
    
    CompositePolyDataMapper2 is similar to
    GenericCompositePolyDataMapper2 but requires that its inputs all
    have the same properties (normals, tcoord, scalars, etc) It will only
    draw polys and it does not support edge flags. The advantage to using
    this class is that it generally should be faster
    
    """
    def __init__(self, obj=None, update=True, **traits):
        tvtk_base.TVTKBase.__init__(self, vtk.vtkCompositePolyDataMapper2, obj, update, **traits)
    
    def _get_input(self):
        return wrap_vtk(self._vtk_obj.GetInput())
    input = traits.Property(_get_input, help=\
        """
        Specify the input data to map.
        """
    )

    _updateable_traits_ = \
    (('scalar_material_mode', 'GetScalarMaterialMode'), ('color_mode',
    'GetColorMode'), ('abort_execute', 'GetAbortExecute'),
    ('cell_id_array_name', 'GetCellIdArrayName'),
    ('populate_selection_settings', 'GetPopulateSelectionSettings'),
    ('vertex_shader_code', 'GetVertexShaderCode'), ('progress_text',
    'GetProgressText'), ('number_of_pieces', 'GetNumberOfPieces'),
    ('resolve_coincident_topology_z_shift',
    'GetResolveCoincidentTopologyZShift'),
    ('interpolate_scalars_before_mapping',
    'GetInterpolateScalarsBeforeMapping'),
    ('global_immediate_mode_rendering',
    'GetGlobalImmediateModeRendering'), ('reference_count',
    'GetReferenceCount'), ('static', 'GetStatic'), ('scalar_mode',
    'GetScalarMode'), ('force_compile_only', 'GetForceCompileOnly'),
    ('progress', 'GetProgress'), ('scalar_visibility',
    'GetScalarVisibility'), ('resolve_coincident_topology',
    'GetResolveCoincidentTopology'), ('release_data_flag',
    'GetReleaseDataFlag'), ('immediate_mode_rendering',
    'GetImmediateModeRendering'), ('composite_id_array_name',
    'GetCompositeIdArrayName'), ('scalar_range', 'GetScalarRange'),
    ('ghost_level', 'GetGhostLevel'), ('process_id_array_name',
    'GetProcessIdArrayName'), ('number_of_sub_pieces',
    'GetNumberOfSubPieces'), ('global_warning_display',
    'GetGlobalWarningDisplay'), ('render_time', 'GetRenderTime'),
    ('piece', 'GetPiece'), ('debug', 'GetDebug'),
    ('resolve_coincident_topology_polygon_offset_faces',
    'GetResolveCoincidentTopologyPolygonOffsetFaces'),
    ('fragment_shader_code', 'GetFragmentShaderCode'),
    ('field_data_tuple_id', 'GetFieldDataTupleId'),
    ('use_lookup_table_scalar_range', 'GetUseLookupTableScalarRange'),
    ('point_id_array_name', 'GetPointIdArrayName'),
    ('geometry_shader_code', 'GetGeometryShaderCode'))
    
    _allow_update_failure_ = \
    ()
    
    _full_traitnames_list_ = \
    (['abort_execute', 'debug', 'global_immediate_mode_rendering',
    'global_warning_display', 'immediate_mode_rendering',
    'interpolate_scalars_before_mapping', 'release_data_flag',
    'scalar_visibility', 'static', 'use_lookup_table_scalar_range',
    'color_mode', 'resolve_coincident_topology', 'scalar_material_mode',
    'scalar_mode', 'cell_id_array_name', 'composite_id_array_name',
    'field_data_tuple_id', 'force_compile_only', 'fragment_shader_code',
    'geometry_shader_code', 'ghost_level', 'number_of_pieces',
    'number_of_sub_pieces', 'piece', 'point_id_array_name',
    'populate_selection_settings', 'process_id_array_name',
    'progress_text', 'render_time',
    'resolve_coincident_topology_polygon_offset_faces',
    'resolve_coincident_topology_z_shift', 'scalar_range',
    'vertex_shader_code'])
    
    def trait_view(self, name=None, view_element=None):
        if view_element is not None or name not in (None, '', 'traits_view', 'full_traits_view', 'view'):
            return super(CompositePolyDataMapper2, self).trait_view(name, view_element)
        if name == 'full_traits_view':
            full_traits_view = \
            View((Item("handler._full_traits_list",show_label=False)),
            title='Edit CompositePolyDataMapper2 properties', scrollable=True, resizable=True,
            handler=TVTKBaseHandler,
            buttons=['OK', 'Cancel'])
            return full_traits_view
        elif name == 'view':
            view = \
            View((['global_immediate_mode_rendering', 'immediate_mode_rendering',
            'interpolate_scalars_before_mapping', 'scalar_visibility', 'static',
            'use_lookup_table_scalar_range'], ['color_mode',
            'resolve_coincident_topology', 'scalar_material_mode', 'scalar_mode'],
            ['cell_id_array_name', 'composite_id_array_name',
            'field_data_tuple_id', 'force_compile_only', 'fragment_shader_code',
            'geometry_shader_code', 'ghost_level', 'number_of_pieces',
            'number_of_sub_pieces', 'piece', 'point_id_array_name',
            'populate_selection_settings', 'process_id_array_name', 'render_time',
            'resolve_coincident_topology_polygon_offset_faces',
            'resolve_coincident_topology_z_shift', 'scalar_range',
            'vertex_shader_code']),
            title='Edit CompositePolyDataMapper2 properties', scrollable=True, resizable=True,
            handler=TVTKBaseHandler,
            buttons=['OK', 'Cancel'])
            return view
        elif name in (None, 'traits_view'):
            traits_view = \
            View((HGroup(spring, "handler.view_type", show_border=True), 
            Item("handler.info.object", editor = InstanceEditor(view_name="handler.view"), style = "custom", show_label=False)),
            title='Edit CompositePolyDataMapper2 properties', scrollable=True, resizable=True,
            handler=TVTKBaseHandler,
            buttons=['OK', 'Cancel'])
            return traits_view
            

